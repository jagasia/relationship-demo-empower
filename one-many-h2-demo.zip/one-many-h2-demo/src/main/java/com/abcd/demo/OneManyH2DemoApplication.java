package com.abcd.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OneManyH2DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(OneManyH2DemoApplication.class, args);
		System.out.println("Hello world");
	}

}
